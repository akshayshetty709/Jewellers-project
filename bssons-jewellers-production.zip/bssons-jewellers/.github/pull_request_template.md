## What & why
<!-- Describe the change and the reason. Link the ticket. -->

## Checklist
- [ ] Tests added/updated and passing
- [ ] No secrets or credentials in the diff
- [ ] Kubernetes/Terraform changes reviewed (`kubectl kustomize` renders, `terraform plan` attached)
- [ ] Docs/runbook updated if behaviour or operations changed
- [ ] Rollback plan: <!-- e.g. revert this PR; Argo CD resyncs -->
