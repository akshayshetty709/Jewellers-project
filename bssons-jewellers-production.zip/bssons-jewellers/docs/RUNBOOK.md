# Runbook

Namespaces: `bssons` (prod), `bssons-staging`. Replace `-n bssons` accordingly.

## First 5 minutes of any incident
```bash
kubectl -n bssons get pods,hpa,ingress
kubectl -n bssons get events --sort-by=.lastTimestamp | tail -20
kubectl -n bssons logs deploy/backend --tail=100
```
Argo CD UI -> `bssons-prod`: is it **OutOfSync** or **Degraded**? What changed last? (`git log -5 -- k8s/overlays/prod`)

## Rollback (fastest, safest)
Git is the source of truth, so roll back in Git:
```bash
git revert <bad-promotion-commit> && git push     # PR + review in real life
```
Then press **Sync** on `bssons-prod`. Emergency only: Argo CD UI -> History and Rollback (the next Git change overrides it).

## api-down
1. `kubectl -n bssons get pods -l app=backend` - CrashLoopBackOff? `kubectl logs --previous`.
2. `kubectl -n bssons get pods -l app=mongo` - DB down makes readiness fail (pods stay Running but NotReady).
3. Bad secret? `kubectl -n bssons get secret bssons-secrets` and check the SealedSecret synced.
4. Roll back (see above).

## high-error-rate
1. Grafana "BSSONS API - RED metrics": which `route` has 5xx?
2. Logs: `kubectl -n bssons logs deploy/backend | grep '"level":50'`.
3. Correlate with the last deployment time; roll back if it started right after.

## high-latency
1. HPA saturated? `kubectl -n bssons get hpa` (at maxReplicas?).
2. MongoDB CPU/memory: `kubectl -n bssons top pod`.
3. Check missing indexes / large result sets; temporarily raise `maxReplicas`.

## crashloop
`kubectl -n bssons describe pod <pod>` -> look at *Last State* (OOMKilled => raise memory limit, ExitCode 1 => read logs, probe failures => check `/api/health/*`).

## Database restore
See `scripts/backup-restore.md`. Always restore into **staging** first and verify.

## Rotate database password
**EKS (AWS Secrets Manager):**
1. Change the password inside MongoDB first (`db.changeUserPassword("bssonsadmin", "<new>")` via `kubectl exec -it mongo-0 -- mongosh -u ... -p ... --authenticationDatabase admin`).
2. `aws secretsmanager put-secret-value --secret-id bssons/prod/mongo --secret-string '{"username":"bssonsadmin","password":"<new>"}'`
3. Force the sync now (otherwise it happens within the 1h refresh interval):
   `kubectl -n bssons annotate externalsecret bssons-secrets force-sync=$(date +%s) --overwrite`
4. Restart so the pods read the new value: `kubectl -n bssons rollout restart deploy/backend`
**kind (Sealed Secrets):** `scripts/seal-secrets.sh prod`, commit, merge; change the password in MongoDB, then `rollout restart deploy/backend`.

## Scheduled hygiene
| Frequency | Task |
|---|---|
| Daily | Check backup CronJob succeeded |
| Weekly | Review Dependabot PRs, Trivy findings, CodeQL alerts |
| Monthly | Restore drill in staging; Kubernetes minor-version upgrade plan |
| Quarterly | Rotate secrets; review IAM / CODEOWNERS; DR game-day |
