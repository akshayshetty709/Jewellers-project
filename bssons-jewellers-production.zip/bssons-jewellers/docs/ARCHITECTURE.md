# Architecture

## Runtime

```mermaid
flowchart LR
  U[User browser] -->|HTTPS 443| ING[Traefik ingress<br/>TLS by cert-manager]
  ING --> FE[frontend Deployment<br/>nginx-unprivileged :8080]
  FE -->|/api/*| BE[backend Deployment<br/>Express :5000]
  BE --> DB[(MongoDB StatefulSet<br/>PVC)]
  PROM[Prometheus] -.scrape /metrics.-> BE
  PROM --> GRAF[Grafana]
  PROM --> AM[Alertmanager]
  CRON[CronJob mongodump] --> DB
```

## Delivery (GitOps)

```mermaid
flowchart LR
  DEV[Developer] -->|PR| GH[GitHub]
  GH --> CI[CI: lint, test, scan]
  CI -->|merge to main| BUILD[Build image, Trivy, SBOM, cosign sign]
  BUILD --> GHCR[(GHCR)]
  BUILD -->|bot commit: new tag| GIT[(Git: k8s/overlays/staging)]
  GIT -->|auto sync| ARGO[Argo CD] --> STG[staging namespace]
  PM[Promote workflow<br/>+ approval] -->|PR bumps prod tag| GIT2[(Git: k8s/overlays/prod)]
  GIT2 -->|manual Sync| ARGO --> PRD[prod namespace]
```

## Key decisions
| Decision | Why |
|---|---|
| GitOps (Argo CD pulls) instead of CI `kubectl apply` | Cluster credentials never leave the cluster; Git is the audit log; drift is auto-corrected |
| Image tag = `sha-<commit>` (never `latest`) | Immutable, traceable, rollback = `git revert` |
| Separate liveness / readiness | A DB outage must not trigger restart storms |
| Namespaces per environment + Pod Security `restricted` | Blast-radius isolation, enforced baseline hardening |
| Default-deny NetworkPolicy | A compromised pod cannot talk to everything |
| AWS Secrets Manager + External Secrets (EKS) / Sealed Secrets (kind) | No plaintext secrets in Git; the cloud secret store is the source of truth, rotation without redeploys |
| Traefik instead of ingress-nginx | ingress-nginx was retired by the Kubernetes project in March 2026 (no security fixes) |
| Terraform with remote state + OIDC | Reviewable infrastructure changes, no long-lived cloud keys |
| Prod = approved PR + manual sync | Two-person rule and a deliberate release moment |
