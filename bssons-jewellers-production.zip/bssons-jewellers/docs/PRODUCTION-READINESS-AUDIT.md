# Production-readiness audit of the original zip

**Verdict:** the original project was a solid *starter / learning* skeleton (React + Express + Mongo, Docker, basic K8s, Argo CD, one workflow).
It was **not** at the level a company expects from a production service. The table shows every gap found and what this version does about it.

| Area | Original | Gap against industry standard | This version |
|---|---|---|---|
| **Tests / lint** | none | No quality gate; regressions reach prod | Jest + Supertest (API), Vitest (web), ESLint on both; coverage threshold in CI |
| **Lockfiles / builds** | `npm install` in Docker & CI | Non-reproducible builds, supply-chain risk | `npm ci` everywhere; lockfiles committed (`make lock`) |
| **Dockerfiles** | single stage, root nginx, no healthcheck, no `.dockerignore` | Large images, root processes, no PID-1 handling | Multi-stage, BuildKit cache, non-root (`node`, `nginx-unprivileged`), `tini`, HEALTHCHECK, `.dockerignore` |
| **API hardening** | open CORS, no headers, regex built from user input | NoSQL/regex injection, no rate limit, info leaks | `helmet`, CORS allow-list, rate limiting, input validation, body-size limit, `x-powered-by` off, safe error handler |
| **Health checks** | one `/api/health`, same probe for live+ready | DB outage restarts healthy pods / serves errors | Separate `/live` and `/ready` (DB-aware), startup probe |
| **Graceful shutdown** | none | Dropped requests during rollouts | SIGTERM handling, preStop hook, `maxUnavailable: 0` |
| **Observability** | README admitted no `/metrics` | Nothing to monitor or alert on | `prom-client` RED metrics, structured JSON logs (pino), ServiceMonitor, alert rules, Grafana dashboard |
| **CI** | one job, builds only | No scans, no signing, no caching, PR pushes nothing safe | Parallel jobs, hadolint, kubeconform, gitleaks, dependency-review, `npm audit`, Trivy, CodeQL, SBOM + provenance, **cosign** signing |
| **CD / GitOps** | tag bump via `sed`, single env | No staging, no approval gate, loop risk | Staging auto-deploy, **prod via approved PR + manual Argo sync**, `[skip ci]` + path filters |
| **Environments** | prod only | Testing in prod | `staging` and `prod` Kustomize overlays |
| **K8s security** | none | Root pods, flat network | Pod Security `restricted`, securityContext, read-only rootfs, dropped capabilities, **default-deny NetworkPolicies**, dedicated ServiceAccounts |
| **K8s reliability** | fixed replicas | No autoscaling, no disruption protection | HPA, PodDisruptionBudgets, topology spread, resource requests/limits |
| **TLS** | HTTP only | Unencrypted traffic | cert-manager + Let's Encrypt (self-signed for local) |
| **Secrets** | manual `kubectl create secret` | Not reproducible, not in Git | AWS Secrets Manager + External Secrets Operator on EKS; Sealed Secrets on kind |
| **Database** | 1 pod, no backups | Data loss | Auth enabled, PVC, nightly `mongodump` CronJob + restore runbook (and Atlas/replica-set guidance) |
| **Platform add-ons** | "install them yourself" | Manual, undocumented cluster state | App-of-apps: Traefik (ingress-nginx was retired in 2026), cert-manager, External Secrets / Sealed Secrets, kube-prometheus-stack installed by Argo CD |
| **Infrastructure** | none | Cluster created by hand | Terraform: remote state, VPC, EKS, EBS CSI, GitHub OIDC (no static AWS keys) |
| **Governance** | none | No review rules | CODEOWNERS, PR template, Dependabot, pre-commit, branch-protection guide |
| **Docs / ops** | short README | No runbook, no DR | Step-by-step README, architecture, runbook, backup/restore |
| **Compose** | Fallback DB password `change-this-password`; no hardening | Weak defaults | Passwords required (`:?`), no DB port published, read-only rootfs, cap_drop |

## Still intentionally out of scope (application features, not DevOps)
Authentication/authorization, payments (PCI), orders and inventory logic, image storage (S3/CDN). Add these as application work; the platform here is ready to host them.

## Honest limits of this template
* MongoDB is single-node: fine for practice/staging; production should use Atlas/DocumentDB or an operator-managed replica set.
* GitHub Actions are pinned to major versions; many companies pin to full commit SHAs (Dependabot can maintain them).
* Alertmanager has no receiver configured (Slack/PagerDuty) - see README step "Alert routing".
