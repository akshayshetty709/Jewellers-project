#!/usr/bin/env python3
"""Offline sanity checks: every YAML/JSON parses, kustomize resource references exist, no placeholder secrets committed."""
import sys, json, pathlib, yaml
root = pathlib.Path(__file__).resolve().parent.parent
bad = 0
for p in root.rglob('*'):
    if any(x in p.parts for x in ('node_modules', '.git', '.terraform')) or not p.is_file(): continue
    try:
        if p.suffix in ('.yaml', '.yml'):
            list(yaml.safe_load_all(p.read_text()))
        elif p.suffix == '.json':
            json.loads(p.read_text())
    except Exception as e:
        print(f'PARSE ERROR {p.relative_to(root)}: {e}'); bad += 1
for k in root.rglob('kustomization.yaml'):
    if 'node_modules' in k.parts: continue
    doc = yaml.safe_load(k.read_text()) or {}
    refs = list(doc.get('resources', []))
    for g in doc.get('configMapGenerator', []):
        for f in g.get('files', []): refs.append(f.split('=')[-1])
    for r in refs:
        if not (k.parent / r).exists():
            print(f'MISSING {k.relative_to(root)} -> {r}'); bad += 1
print('validate: OK' if not bad else f'validate: {bad} problem(s)')
sys.exit(1 if bad else 0)
