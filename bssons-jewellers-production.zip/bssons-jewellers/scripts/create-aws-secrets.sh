#!/usr/bin/env bash
# Creates the MongoDB credentials secret in AWS Secrets Manager: bssons/<env>/mongo = {"username","password"}.
# Usage: scripts/create-aws-secrets.sh <staging|prod>      (region: AWS_REGION, default ap-south-1)
# Idempotent: does nothing if the secret already exists. The password is generated here and never printed.
set -euo pipefail
ENVIRONMENT="${1:?usage: $0 <staging|prod>}"
[[ "$ENVIRONMENT" == "staging" || "$ENVIRONMENT" == "prod" ]] || { echo "env must be staging|prod"; exit 1; }
REGION="${AWS_REGION:-ap-south-1}"
NAME="bssons/${ENVIRONMENT}/mongo"

if aws secretsmanager describe-secret --secret-id "$NAME" --region "$REGION" >/dev/null 2>&1; then
  echo "Secret $NAME already exists in $REGION - nothing to do."; exit 0
fi
umask 077
TMP="$(mktemp)"; trap 'rm -f "$TMP"' EXIT
printf '{"username":"bssonsadmin","password":"%s"}' "$(openssl rand -hex 24)" > "$TMP"   # hex = URL-safe in the Mongo URI
aws secretsmanager create-secret --name "$NAME" --region "$REGION" \
  --description "BSSONS ${ENVIRONMENT} MongoDB credentials" \
  --secret-string "file://$TMP" --query 'ARN' --output text
echo "Created $NAME in $REGION."
