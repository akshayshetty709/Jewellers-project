#!/usr/bin/env bash
# Replaces placeholders (OWNER, REPO, domain, e-mail) across manifests and workflows.
# Usage: scripts/init-project.sh <github-owner> <repo-name> <base-domain> <ops-email> [mode]
#   mode = kind | eks | eks-nodomain   (default: real domain + Let's Encrypt, Sealed Secrets)
#   local kind practice : scripts/init-project.sh akshay bssons-jewellers localtest.me me@example.com kind
#   AWS EKS             : scripts/init-project.sh akshay bssons-jewellers bssons.in ops@bssons.in eks
#                         (Let's Encrypt TLS + secrets from AWS Secrets Manager via External Secrets)
#   AWS EKS, no domain  : scripts/init-project.sh akshay bssons-jewellers bssons.local me@example.com eks-nodomain
#                         (same, but self-signed TLS; you map the hostnames in your hosts file)
set -euo pipefail
[ $# -ge 4 ] || { sed -n '2,10p' "$0"; exit 1; }
OWNER="$1"; REPO="$2"; DOMAIN="$3"; EMAIL="$4"; MODE="${5:-letsencrypt}"
OWNER_LC=$(echo "$OWNER" | tr '[:upper:]' '[:lower:]')   # GHCR image paths must be lowercase
cd "$(dirname "$0")/.."

FILES=$(grep -rlE 'OWNER|example\.com' . \
  --exclude-dir=.git --exclude-dir=node_modules --exclude-dir=.terraform \
  --exclude=README.md --exclude=init-project.sh --exclude='*.md' || true)

for f in $FILES; do
  sed -i \
    -e "s#ghcr.io/OWNER/#ghcr.io/${OWNER_LC}/#g" \
    -e "s#OWNER/REPO#${OWNER}/${REPO}#g" \
    -e "s#REPO-backend#${REPO}-backend#g; s#REPO-frontend#${REPO}-frontend#g" \
    -e "s#@OWNER#@${OWNER}#g" \
    -e "s#staging\.bssons\.example\.com#staging.${DOMAIN}#g" \
    -e "s#bssons\.example\.com#${DOMAIN}#g" \
    -e "s#devops@example\.com#${EMAIL}#g" \
    "$f"
done

if [ "$MODE" = "selfsigned" ] || [ "$MODE" = "kind" ] || [ "$MODE" = "eks-nodomain" ]; then
  sed -i -E 's/letsencrypt-(staging|prod)/selfsigned/g' k8s/base/ingress.yaml k8s/overlays/*/kustomization.yaml
  echo "TLS issuer set to 'selfsigned' (local practice)."
fi
if [ "$MODE" = "eks" ] || [ "$MODE" = "eks-nodomain" ]; then
  for e in staging prod; do
    sed -i 's|^  # - external-secret.yaml.*|  - external-secret.yaml|' "k8s/overlays/${e}/kustomization.yaml"
  done
  echo "External Secrets enabled in both overlays (secrets come from AWS Secrets Manager)."
fi
# GHCR image names: ghcr.io/<owner>/<repo>-backend (lowercase)
REPO_LC=$(echo "$REPO" | tr '[:upper:]' '[:lower:]')
sed -i "s#ghcr.io/${OWNER_LC}/${REPO}-#ghcr.io/${OWNER_LC}/${REPO_LC}-#g" k8s/base/*.yaml k8s/overlays/*/kustomization.yaml
echo "Done. Review with: git diff"
