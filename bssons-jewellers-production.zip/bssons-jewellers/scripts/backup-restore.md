# MongoDB backup / restore (kubectl)

Backups run nightly (CronJob `mongo-backup`). Trigger one manually:
    kubectl -n bssons create job --from=cronjob/mongo-backup manual-backup-$(date +%s)

List backups:
    kubectl -n bssons run ls-backups --rm -it --restart=Never --image=busybox \
      --overrides='{"spec":{"containers":[{"name":"x","image":"busybox","command":["ls","-lh","/backup"],"volumeMounts":[{"name":"b","mountPath":"/backup"}]}],"volumes":[{"name":"b","persistentVolumeClaim":{"claimName":"mongo-backups"}}]}}'

Restore (DESTRUCTIVE - practise in staging first): copy the archive out, then
    kubectl -n bssons exec -i mongo-0 -- mongorestore --username <u> --password <p> --authenticationDatabase admin --archive --gzip --drop < bssons-YYYYMMDD-HHMMSS.archive.gz
