#!/usr/bin/env bash
# Creates an ENCRYPTED SealedSecret for an environment (safe to commit - only the cluster can decrypt it).
# Usage: scripts/seal-secrets.sh <staging|prod>
# Requires: kubectl (pointing at the target cluster), kubeseal, openssl, sealed-secrets controller running.
set -euo pipefail
ENVIRONMENT="${1:?usage: $0 <staging|prod>}"
case "$ENVIRONMENT" in staging) NS=bssons-staging ;; prod) NS=bssons ;; *) echo "env must be staging|prod"; exit 1 ;; esac
cd "$(dirname "$0")/.."
OUT="k8s/overlays/${ENVIRONMENT}/sealed-secret.yaml"

USER_NAME="bssonsadmin"
PASS="$(openssl rand -hex 24)"      # hex => URL-safe, no escaping problems inside the Mongo URI
URI="mongodb://${USER_NAME}:${PASS}@mongo:27017/bssons?authSource=admin"

kubectl create secret generic bssons-secrets --namespace "$NS" \
  --from-literal=mongo-username="$USER_NAME" \
  --from-literal=mongo-password="$PASS" \
  --from-literal=mongo-uri="$URI" \
  --dry-run=client -o yaml \
| kubeseal --controller-name sealed-secrets-controller --controller-namespace kube-system --format yaml > "$OUT"

sed -i 's|^  # - sealed-secret.yaml.*|  - sealed-secret.yaml|' "k8s/overlays/${ENVIRONMENT}/kustomization.yaml"
unset PASS URI
echo "Wrote $OUT and enabled it in the overlay. Commit and push it."
echo "NOTE: sealed secrets are bound to this cluster's key. Back up the controller key (see README 'Disaster recovery')."
