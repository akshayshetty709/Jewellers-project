#!/usr/bin/env bash
# Copies values from `terraform output` into the Git-tracked manifests (run once after `terraform apply`, then commit).
# Usage: scripts/configure-eks.sh
set -euo pipefail
cd "$(dirname "$0")/.."
TF=terraform/envs/dev
ROLE_ARN="$(terraform -chdir="$TF" output -raw external_secrets_role_arn)"
REGION="$(terraform -chdir="$TF" output -raw region)"

sed -i "s#eks.amazonaws.com/role-arn: .*#eks.amazonaws.com/role-arn: ${ROLE_ARN}#" argocd/apps-eks/external-secrets.yaml
sed -i "s#region: [a-z0-9-]*#region: ${REGION}#" k8s/platform/aws/cluster-secret-store.yaml
echo "ESO role : ${ROLE_ARN}"
echo "Region   : ${REGION}"
echo "Now commit and push:  git add -A && git commit -m 'chore: configure EKS' && git push"
