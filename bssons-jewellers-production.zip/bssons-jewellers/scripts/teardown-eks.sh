#!/usr/bin/env bash
# Deletes EVERYTHING created for the EKS practice run, in the order that avoids orphaned (billed) AWS resources:
#   1. Argo CD apps (cascade-deletes workloads, the Traefik load balancer, and their volumes)
#   2. leftover PVCs  3. AWS Secrets Manager secrets  4. terraform destroy (cluster, VPC, NAT, roles)
# Usage: scripts/teardown-eks.sh        (asks you to type "destroy"). The bootstrap stack is destroyed separately (README).
set -uo pipefail
cd "$(dirname "$0")/.."
REGION="${AWS_REGION:-ap-south-1}"
read -r -p "This DELETES the EKS cluster and all data. Type 'destroy' to continue: " ANSWER
[[ "$ANSWER" == "destroy" ]] || { echo "Aborted."; exit 1; }

echo "== 1/4 Deleting Argo CD applications (this removes the AWS load balancer)"
# workloads first (while External Secrets etc. still exist), then the platform "root" apps
# (roots have selfHeal, so they must be deleted rather than their children)
kubectl -n argocd delete application bssons-staging bssons-prod --ignore-not-found --wait=true --timeout=10m
kubectl -n argocd delete application platform-eks platform-common platform-kind --ignore-not-found --wait=true --timeout=15m

echo "== 2/4 Deleting persistent volumes claims (EBS volumes)"
for ns in bssons bssons-staging monitoring; do kubectl -n "$ns" delete pvc --all --ignore-not-found --wait=true --timeout=5m; done
echo "Waiting for load balancers to disappear..."
for i in $(seq 1 30); do
  n=$(kubectl get svc -A -o jsonpath='{range .items[?(@.spec.type=="LoadBalancer")]}{.metadata.name}{"\n"}{end}' | wc -l)
  [ "$n" -eq 0 ] && break; sleep 10
done

echo "== 3/4 Deleting AWS Secrets Manager secrets (no recovery window => no lingering charge)"
for e in staging prod; do
  aws secretsmanager delete-secret --secret-id "bssons/$e/mongo" --force-delete-without-recovery --region "$REGION" >/dev/null 2>&1 \
    && echo "deleted bssons/$e/mongo" || echo "bssons/$e/mongo not found (ok)"
done

echo "== 4/4 terraform destroy (about 10-15 minutes)"
terraform -chdir=terraform/envs/dev destroy -auto-approve
echo
echo "Done. Verify nothing is left: see README / docs/EKS-DEPLOYMENT-GUIDE.md -> 'Verify nothing is billing'."
