#!/usr/bin/env bash
# Installs Argo CD and hands the cluster over to GitOps (platform add-ons + both environments).
# Usage: scripts/bootstrap-argocd.sh --kind      # local kind cluster (Traefik hostPorts + Sealed Secrets)
#        scripts/bootstrap-argocd.sh --eks       # AWS EKS (Traefik NLB + External Secrets / AWS Secrets Manager)
# Private GitHub repo? export ARGOCD_REPO_USER and ARGOCD_REPO_TOKEN first (token needs read access to repo contents).
set -euo pipefail
MODE="${1:-}"; [[ "$MODE" == "--kind" || "$MODE" == "--eks" ]] || { sed -n '2,6p' "$0"; exit 1; }
ARGOCD_VERSION="${ARGOCD_VERSION:-v3.4.13}"     # supported minor as of Nov 2026; bump deliberately (Argo CD releases page)
cd "$(dirname "$0")/.."

REPO_URL=$(grep -m1 'repoURL:' argocd/app-staging.yaml | awk '{print $2}')
case "$REPO_URL" in *OWNER*) echo "Run scripts/init-project.sh first (placeholders still present)."; exit 1 ;; esac

kubectl create namespace argocd --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -n argocd --server-side --force-conflicts \
  -f "https://raw.githubusercontent.com/argoproj/argo-cd/${ARGOCD_VERSION}/manifests/install.yaml"
kubectl -n argocd rollout status deploy/argocd-server --timeout=300s
kubectl -n argocd rollout status statefulset/argocd-application-controller --timeout=300s

if [[ -n "${ARGOCD_REPO_TOKEN:-}" ]]; then
  echo "Registering private repository credentials in Argo CD..."
  kubectl -n argocd create secret generic repo-bssons \
    --from-literal=type=git --from-literal=url="$REPO_URL" \
    --from-literal=username="${ARGOCD_REPO_USER:?set ARGOCD_REPO_USER}" --from-literal=password="$ARGOCD_REPO_TOKEN" \
    --dry-run=client -o yaml | kubectl apply -f -
  kubectl -n argocd label secret repo-bssons argocd.argoproj.io/secret-type=repository --overwrite
fi

kubectl apply -f argocd/project.yaml
kubectl apply -f argocd/root-common.yaml           # cert-manager, kube-prometheus-stack, ClusterIssuers
if [[ "$MODE" == "--kind" ]]; then
  kubectl apply -f argocd/root-kind.yaml           # Traefik (hostPort) + Sealed Secrets
else
  kubectl apply -f argocd/root-platform-eks.yaml   # Traefik (NLB) + External Secrets + ClusterSecretStore
fi
kubectl apply -f argocd/app-staging.yaml
kubectl apply -f argocd/app-prod.yaml

echo
echo "Argo CD initial admin password:"
kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' | base64 -d; echo
echo "UI:  kubectl -n argocd port-forward svc/argocd-server 9443:443   ->  https://localhost:9443  (user: admin)"
