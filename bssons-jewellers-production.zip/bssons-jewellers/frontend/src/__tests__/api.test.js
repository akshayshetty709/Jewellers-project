import { describe, it, expect, vi, afterEach } from 'vitest';
import { getProducts } from '../api.js';

afterEach(() => vi.restoreAllMocks());

describe('getProducts', () => {
  it('returns parsed JSON on success', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => [{ name: 'Ring' }] }));
    await expect(getProducts()).resolves.toEqual([{ name: 'Ring' }]);
  });
  it('throws when the API responds with an error', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: false }));
    await expect(getProducts()).rejects.toThrow('Unable to load products');
  });
});
