import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Local `npm run dev` without Docker: forward /api to the backend.
  server: { proxy: { '/api': 'http://localhost:5000' } },
  test: { environment: 'node' }
});
