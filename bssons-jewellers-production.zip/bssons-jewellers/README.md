# BSSONS JEWELLERS — Production-Grade DevOps Project

A full-stack jewellery store (React + Express + MongoDB) wrapped in the delivery platform a real IT company would expect:
**tested, scanned, signed container images → GitOps deployment with Argo CD → Kubernetes with security, autoscaling, TLS, monitoring and backups → infrastructure as code with Terraform.**

> Read [`docs/PRODUCTION-READINESS-AUDIT.md`](docs/PRODUCTION-READINESS-AUDIT.md) to see what was missing from the original zip and what was added.

---

## Table of contents
0. [What you will build / learn](#0-what-you-will-build--learn)
1. [Repository layout](#1-repository-layout)
2. [Prerequisites — tools and accounts](#2-prerequisites--tools-and-accounts)
3. [Step 1 — Run the app locally (Docker Compose)](#3-step-1--run-the-app-locally-docker-compose)
4. [Step 2 — Tests, lint and lockfiles](#4-step-2--tests-lint-and-lockfiles)
5. [Step 3 — GitHub repository, secrets and branch protection](#5-step-3--github-repository-secrets-and-branch-protection)
6. [Step 4 — CI/CD pipeline explained and first run](#6-step-4--cicd-pipeline-explained-and-first-run)
7. [Step 5 — Local Kubernetes + Argo CD (free path, kind)](#7-step-5--local-kubernetes--argo-cd-free-path-kind)
8. [Step 6 — Release flow: staging → production](#8-step-6--release-flow-staging--production)
9. [Step 7 — Monitoring, dashboards and alerts](#9-step-7--monitoring-dashboards-and-alerts)
10. [Step 8 — Real cloud: Amazon EKS + AWS Secrets Manager (optional, costs money)](#10-step-8--real-cloud-amazon-eks-with-aws-secrets-manager-optional-costs-money)
11. [Day-2 operations](#11-day-2-operations)
12. [Security model](#12-security-model)
13. [Troubleshooting](#13-troubleshooting)
14. [What is still missing for a *real* store](#14-what-is-still-missing-for-a-real-store)
15. [Practice exercises and interview talking points](#15-practice-exercises-and-interview-talking-points)
16. [Clean-up](#16-clean-up)
17. [What has and has not been verified](#17-what-has-and-has-not-been-verified)

---

## 0. What you will build / learn

```mermaid
flowchart LR
  A[git push] --> B[GitHub Actions CI<br/>lint · test · scan]
  B --> C[Build image<br/>Trivy · SBOM · cosign]
  C --> D[(GHCR)]
  C --> E[Bot commits new tag<br/>to Git]
  E --> F[Argo CD]
  F --> G[staging namespace]
  H[Approved promotion PR] --> F
  F --> I[prod namespace]
  I --> J[Prometheus · Grafana · Alertmanager]
```

| Skill area | Where you practise it |
|---|---|
| Docker (multi-stage, non-root, healthchecks) | `backend/Dockerfile`, `frontend/Dockerfile` |
| CI (quality gates, DevSecOps scanning, signing) | `.github/workflows/ci.yml`, `codeql.yml` |
| CD / GitOps, environment promotion | `argocd/`, `k8s/overlays/*`, `promote-prod.yml` |
| Kubernetes (probes, HPA, PDB, NetworkPolicy, PSA, StatefulSet, CronJob) | `k8s/base/*` |
| Secrets management | Sealed Secrets (kind) · **AWS Secrets Manager + External Secrets Operator (EKS)** |
| Observability (metrics, logs, alerts, dashboards) | `backend/src/metrics.js`, `k8s/base/monitoring.yaml` |
| Infrastructure as Code (remote state, OIDC) | `terraform/*` |
| Operations (runbook, backup/restore, DR) | `docs/RUNBOOK.md`, `scripts/backup-restore.md` |

---

## 1. Repository layout

```text
bssons-jewellers/
├── backend/                     Express API (config, logger, metrics, routes, tests, Dockerfile)
│   ├── src/{app.js,server.js,config,middleware,routes,models,metrics.js,logger.js,seed.js}
│   └── tests/app.test.js
├── frontend/                    React + Vite SPA, nginx-unprivileged image, tests
├── k8s/
│   ├── base/                    Deployments, Services, HPA, PDB, NetworkPolicies, Mongo, backup, Ingress, ServiceMonitor
│   ├── overlays/{staging,prod}/ Per-environment settings + image tags (CI/promotion edit these)
│   └── platform/                Cluster-wide config (ClusterIssuers; aws/ = ClusterSecretStore + StorageClass)
├── argocd/
│   ├── project.yaml             AppProject (RBAC boundary)
│   ├── root-common.yaml         App-of-apps: add-ons for every cluster
│   ├── root-kind.yaml           App-of-apps: local-only add-ons
│   ├── root-platform-eks.yaml   App-of-apps: AWS-only add-ons
│   ├── apps/common/             cert-manager, kube-prometheus-stack, platform-config (ClusterIssuers)
│   ├── apps/kind/               Traefik (hostPorts), Sealed Secrets
│   ├── apps-eks/                Traefik (AWS load balancer), External Secrets Operator, secret-store config
│   └── app-staging.yaml · app-prod.yaml
├── terraform/{bootstrap,envs/dev}   Remote state, GitHub OIDC role, VPC, EKS
├── monitoring/                  Prometheus/Grafana for the local Compose profile
├── scripts/                     init-project, bootstrap-argocd, seal-secrets (kind), create-aws-secrets + configure-eks + teardown-eks (AWS), validate.py
├── docs/                        EKS deployment guide, audit, architecture, runbook
├── .github/                     Workflows, Dependabot, CODEOWNERS, PR template
├── docker-compose.yml · Makefile · .env.example · .pre-commit-config.yaml
```

---

## 2. Prerequisites — tools and accounts

### Accounts
| Account | Needed for | Cost |
|---|---|---|
| GitHub | Repo, Actions, GHCR registry | Free |
| AWS (optional, only Step 8) | EKS via Terraform | **Paid** (~US$0.40–0.50/hour ≈ ₹1,000/day while running; delete the same day) |
| A domain (optional) | Real TLS with Let's Encrypt | ~₹800/yr. Not needed for local practice (`localtest.me` works) |

### Tools to install (Linux / macOS / WSL2)
| Tool | Version | Check |
|---|---|---|
| Git | any recent | `git --version` |
| Node.js | 20+ | `node -v` |
| Docker (Desktop or Engine) + Compose v2 | 24+ | `docker compose version` |
| kubectl | 1.30+ | `kubectl version --client` |
| kind | 0.24+ | `kind version` |
| kubeseal | 0.27+ | `kubeseal --version` |
| GitHub CLI (`gh`) – optional but convenient | any | `gh --version` |
| Terraform + AWS CLI (Step 8 only) | 1.9+ / v2 | `terraform -version` |
| pre-commit (optional) | any | `pre-commit --version` |

Give Docker at least **6 GB RAM** and 4 CPUs if you will run kind + Argo CD + Prometheus (they are heavy).

---

## 3. Step 1 — Run the app locally (Docker Compose)

```bash
unzip bssons-jewellers.zip && cd bssons-jewellers

# 1. Create your local secrets file (never committed — it is in .gitignore)
cp .env.example .env
# Generate strong passwords and paste them into .env:
openssl rand -base64 24      # use for MONGO_ROOT_PASSWORD
openssl rand -base64 24      # use for GRAFANA_ADMIN_PASSWORD
```

#### 2. Generate and commit the lockfiles (one-time, mandatory)
The Dockerfiles and CI use `npm ci`, which refuses to run without `package-lock.json` (it installs *exactly* the versions in the lockfile — reproducible builds, a standard company practice).

```bash
make lock
git add backend/package-lock.json frontend/package-lock.json
git commit -m "chore: add lockfiles"
```
* `make` reads the `Makefile`; `make lock` runs `npm install --package-lock-only` in `backend/` and `frontend/` (writes the lockfile without downloading `node_modules`). `make help` lists every shortcut.
* Equivalent without make: `cd backend && npm install`, `cd ../frontend && npm install`, then commit the two lockfiles.
* Makefile recipes must be indented with a real **Tab** (not spaces) — `.editorconfig` enforces that.
* Whenever you change a dependency in a `package.json`, re-run it and commit the lockfile in the same PR.
* No `make`? Ubuntu/WSL: `sudo apt install make` · macOS: `xcode-select --install`.

```bash
# 3. Build and start
make up                       # = docker compose up --build -d
docker compose ps             # all services should be "healthy"/"running"

# 4. Load demo products
make seed
```

Open:
| URL | What |
|---|---|
| http://localhost:8080 | Storefront |
| http://localhost:5000/api/health/ready | Readiness (200 only when the DB is connected) |
| http://localhost:5000/api/products | Products API |
| http://localhost:5000/metrics | Prometheus metrics |

**Local monitoring (optional):**
```bash
make monitoring
```
Prometheus http://localhost:9090 (Status → Targets: `bssons-api` UP) · Grafana http://localhost:3000 (user `admin`, password from `.env`) → Dashboards → BSSONS → *BSSONS API - RED metrics*.

Generate some traffic to see graphs move:
```bash
for i in $(seq 1 200); do curl -s localhost:8080/api/products > /dev/null; done
```

Stop: `make down` (data volume kept). Wipe data: `docker compose down -v`.

**Understanding what you just ran**
* Only the frontend (8080) and API (5000) are published; MongoDB has **no host port** — nothing outside Docker can reach it.
* Containers run as non-root with dropped Linux capabilities and (for the API) a read-only filesystem.

---

## 4. Step 2 — Tests, lint and lockfiles

```bash
make install     # npm ci in both apps (uses the lockfiles)
make lint
make test        # Jest (API) + Vitest (web)
make validate    # offline YAML/JSON + kustomize reference checks
```

What the API tests prove (`backend/tests/app.test.js`): liveness/readiness behaviour, regex-injection escaping, NoSQL-operator injection blocked, malformed id rejected, 404 handling, metrics exposed, security headers present.

Optional git hooks (secret scanning, YAML/Dockerfile lint on every commit):
```bash
pip install pre-commit && pre-commit install
```

---

## 5. Step 3 — GitHub repository, secrets and branch protection

### 5.1 Replace the placeholders
The manifests contain `OWNER`, `REPO`, `bssons.example.com`, `devops@example.com`. One command replaces them everywhere:

```bash
# real domain + Let's Encrypt:
scripts/init-project.sh <github-username> bssons-jewellers bssons.in you@bssons.in

# OR free local practice with kind (self-signed TLS, *.localtest.me resolves to 127.0.0.1):
scripts/init-project.sh <github-username> bssons-jewellers localtest.me you@example.com kind

# OR AWS EKS (secrets from AWS Secrets Manager) - see docs/EKS-DEPLOYMENT-GUIDE.md:
scripts/init-project.sh <github-username> bssons-jewellers bssons.in you@bssons.in eks
scripts/init-project.sh <github-username> bssons-jewellers bssons.local you@example.com eks-nodomain   # no domain
```
Review: `git diff` (after the first commit) — you should see image names like `ghcr.io/<username>/bssons-jewellers-backend`.

### 5.2 Create the repository and push
```bash
git init -b main
git add .
git commit -m "feat: initial production-grade BSSONS platform"
gh repo create bssons-jewellers --public --source=. --remote=origin --push
# (or create it in the web UI and: git remote add origin ... && git push -u origin main)
# Public is recommended for practice: the repo holds no secrets, and on GitHub Free it keeps environment approvals,
# branch protection and Argo CD access simple. For a private repo, give Argo CD a token (see docs/EKS-DEPLOYMENT-GUIDE.md, Part F).
```

### 5.3 GitHub settings (Settings → …)
1. **Actions → General → Workflow permissions:** "Read repository contents" is fine (workflows request what they need). Tick **Allow GitHub Actions to create and approve pull requests** (the promotion workflow opens PRs).
2. **Environments → New environment** (`production`): add yourself/teammates under **Required reviewers**. This is the approval gate for `promote-prod.yml`.
   (Create `infrastructure` the same way if you do Step 8.)
3. **Branch protection** (Settings → Branches → add rule for `main`), the standard company setup:
   * Require a pull request before merging, **1 approval**, dismiss stale approvals
   * Require review from Code Owners
   * Require status checks: `Backend lint + test`, `Frontend lint + test + build`, `Dockerfile + Kubernetes manifest checks`, `Secret scan (gitleaks)`, `Image backend`, `Image frontend`
   * Require branches to be up to date; block force pushes
4. **Security → Code security:** enable *Dependabot alerts*, *Dependabot security updates*, *Secret scanning + push protection*, *Code scanning* (CodeQL workflow already included).
5. **The bot push problem.** The CI bot commits the new image tag to `main`, which branch protection blocks. Pick one (this is exactly the decision real teams make):
   * *Practice setup (simplest):* create a **fine-grained PAT** (your profile → Settings → Developer settings → Fine-grained tokens) limited to this repo with **Contents: Read & write** and **Pull requests: Read & write**; add it as repository secret **`GITOPS_PAT`**; and add yourself as bypass actor for the rule (or untick "Do not allow bypassing" for admins).
   * *Company setup:* a GitHub App with the same permissions, allowed in the ruleset's bypass list, or a separate `bssons-gitops` repository that only holds `k8s/` (cleanest separation of code and deploy state).
6. **Packages:** after the first successful image push, GitHub → your profile → *Packages* → each package → *Package settings* → **Change visibility → Public** (easiest for kind practice). Private registry alternative is in [§13](#13-troubleshooting).

---

## 6. Step 4 — CI/CD pipeline explained and first run

Open a feature branch, change something small, push, open a PR — watch **Actions**.

| Job | What it does | Fails when |
|---|---|---|
| `Backend lint + test` | `npm ci`, ESLint, Jest with coverage threshold, `npm audit` | Lint/test failure, high-severity vulnerable dependency |
| `Frontend lint + test + build` | same + production build | same |
| `Dockerfile + Kubernetes manifest checks` | hadolint, renders `staging` & `prod` overlays with `kubectl kustomize`, validates with kubeconform | Bad Dockerfile practice, invalid manifest |
| `Secret scan` | gitleaks over full history | A secret/token is committed |
| `Dependency review` (PR) | blocks PRs adding high-severity vulnerable packages | — |
| `Image <service>` | builds image, **Trivy** scan (fixable HIGH/CRITICAL fail), on `main`: push to GHCR with provenance + SBOM, **cosign keyless signature** | Vulnerable image |
| `Update GitOps manifest (staging)` (main only) | `yq` sets `newTag: sha-<commit>` in `k8s/overlays/staging`, commits `[skip ci]` | — |
| `CodeQL` | static analysis (weekly + every PR) | — |

Why these choices: images are tagged by commit (`sha-1a2b3c4d5e6f`), never `latest`; PRs build and scan but never push; the commit that updates the tag is excluded from CI to avoid infinite loops; workflow permissions default to read-only.

**Verify a signature** (proves the image came from your pipeline):
```bash
cosign verify ghcr.io/<owner>/bssons-jewellers-backend:sha-<12chars> \
  --certificate-identity-regexp 'https://github.com/<owner>/bssons-jewellers/.*' \
  --certificate-oidc-issuer https://token.actions.githubusercontent.com
```

Merge the PR → a new `sha-…` tag is pushed and `k8s/overlays/staging/kustomization.yaml` changes automatically. Argo CD (next step) will deploy it.

---

## 7. Step 5 — Local Kubernetes + Argo CD (free path, kind)

Prerequisite: you ran `init-project.sh … localtest.me … kind`, pushed to GitHub, **CI finished and the bot committed a `sha-…` tag** into `k8s/overlays/staging/kustomization.yaml` (`git pull` and check — otherwise pods fail with `ImagePullBackOff`), and the images are public (Step 3.6).

### 7.1 Create the cluster
```bash
make kind-up                 # 1 control-plane + 2 workers; host ports 8081→80, 8443→443
kubectl get nodes            # 3 nodes Ready
```

### 7.2 Install Argo CD and hand over to GitOps
```bash
scripts/bootstrap-argocd.sh --kind
```
This installs Argo CD, then applies the `AppProject`, the platform app-of-apps (cert-manager, Prometheus/Grafana, **Traefik** ingress with hostPorts, Sealed Secrets), and the staging/prod applications. (ingress-nginx was replaced by Traefik because the Kubernetes project retired ingress-nginx in March 2026 — it receives no more security fixes.) Watch:
```bash
kubectl -n argocd get applications -w
```
Wait until `traefik`, `cert-manager`, `sealed-secrets`, `kube-prometheus-stack`, `platform-config` are **Synced/Healthy** (5–10 min; Prometheus is large). Argo UI (port 9443 because kind already uses 8443 for HTTPS):
```bash
kubectl -n argocd port-forward svc/argocd-server 9443:443    # new terminal; https://localhost:9443, user admin
```
(The script prints the initial admin password; change it after first login.)

> `bssons-staging` / `bssons-prod` will show *Degraded/Progressing* until the secret exists (next step) — that is expected.

### 7.3 Pin chart versions (after everything is Healthy)
The add-on charts use version ranges (`"*"`, `"2.*"`) so the first install works on any date. Production practice is to pin the exact version that you tested:
```bash
kubectl -n argocd get applications -o custom-columns=NAME:.metadata.name,REVISION:.status.sync.revision
```
Copy each chart's revision into its `targetRevision` in `argocd/apps/**` (e.g. `"27.1.0"`), commit and push. From then on, upgrades are deliberate pull requests.

### 7.4 Create the database secret (encrypted, in Git — kind path)
```bash
scripts/seal-secrets.sh staging      # generates random password, encrypts with the cluster key
scripts/seal-secrets.sh prod
git add k8s/overlays && git commit -m "chore: add sealed secrets" && git push
```
Only the cluster can decrypt these files, so they are safe to commit. Argo CD syncs `bssons-staging` automatically within ~3 minutes (or press **Refresh/Sync**).

### 7.5 Verify staging
```bash
kubectl -n bssons-staging get pods,hpa,ingress,certificate
# all pods Running, certificate READY=True

# load demo products (production guard requires explicit permission)
kubectl -n bssons-staging exec deploy/backend -- env ALLOW_SEED=true node src/seed.js
```
Browse **https://staging.localtest.me:8443** (accept the self-signed certificate warning).
Test the API: `curl -k https://staging.localtest.me:8443/api/products`.

### 7.6 Production namespace
`bssons-prod` has *manual sync* by design **and still points to image tag `latest`**, so first do the promotion in Step 6 (it commits a real `sha-…` tag), `git pull`, then in the Argo UI open `bssons-prod` → **Sync**. Browse https://localtest.me:8443. (On kind both environments share the cluster; real companies use separate clusters or accounts for prod.)

### 7.7 Prove the platform properties
```bash
# Self-healing: delete a pod -> recreated
kubectl -n bssons-staging delete pod -l app=backend --wait=false; kubectl -n bssons-staging get pods -w

# Drift correction: scale by hand, Argo reverts (staging has selfHeal)
kubectl -n bssons-staging scale deploy/frontend --replicas=5   # watch it return to the Git value

# Network policy: backend must NOT reach the internet (needs a CNI that enforces policies)
kubectl -n bssons-staging exec deploy/backend -- node -e "fetch('https://example.com',{signal:AbortSignal.timeout(4000)}).then(()=>console.log('REACHABLE')).catch(()=>console.log('BLOCKED'))"

# Readiness vs liveness: stop the DB, backend pods go NotReady but are NOT restarted
kubectl -n bssons-staging scale statefulset/mongo --replicas=0
kubectl -n bssons-staging get pods -l app=backend      # READY 0/1, RESTARTS unchanged
kubectl -n bssons-staging scale statefulset/mongo --replicas=1   # Argo will also restore this
```

---

## 8. Step 6 — Release flow: staging → production

1. Merge a PR to `main` → CI builds `sha-abc123…` → bot updates staging → Argo deploys → **test in staging**.
2. GitHub → **Actions → "Promote to production" → Run workflow** (leave tag empty = what staging runs now, or paste a tag).
3. Reviewers approve the `production` environment gate → the workflow opens a **PR** "Promote sha-… to production".
4. Another person reviews/merges the PR (CODEOWNERS).
5. Argo CD shows `bssons-prod` **OutOfSync** → check the diff → **Sync**.
6. Watch dashboards/alerts for 15 minutes.

**Rollback:** `git revert` the promotion commit, merge, Sync (details in `docs/RUNBOOK.md`). Rolling updates use `maxUnavailable: 0` and readiness probes, so a broken version never receives traffic.

Hotfix path: same flow with a tag from a hotfix branch; there is no shortcut around review in production.

---

## 9. Step 7 — Monitoring, dashboards and alerts

Installed by Argo CD (kube-prometheus-stack). Access:
```bash
kubectl -n monitoring port-forward svc/kube-prometheus-stack-grafana 3000:80          # http://localhost:3000
kubectl -n monitoring port-forward svc/kube-prometheus-stack-prometheus 9090:9090     # http://localhost:9090
kubectl -n monitoring port-forward svc/kube-prometheus-stack-alertmanager 9093:9093   # http://localhost:9093
```
Grafana login: `admin` / the `adminPassword` in `argocd/apps/common/kube-prometheus-stack.yaml` — **change it** (use `grafana.admin.existingSecret` with a sealed secret for real use).

* **Dashboard:** Dashboards → *BSSONS API - RED metrics* (Rate, Errors, Duration). It is provisioned from a ConfigMap shipped in `k8s/base`, so it follows the app through GitOps.
* **Targets:** Prometheus → Status → Targets → the `backend` ServiceMonitor must be **UP** in both namespaces.
* **Alerts:** `ApiDown`, `ApiHighErrorRate`, `ApiHighLatencyP95`, `PodCrashLooping` (see `k8s/base/monitoring.yaml`). Each links to a runbook section.

Generate traffic and an incident to watch an alert fire:
```bash
for i in $(seq 1 300); do curl -sk https://staging.localtest.me:8443/api/products >/dev/null; done   # (rate limit may return 429 - that is working as designed)
kubectl -n bssons-staging scale deploy/backend --replicas=0     # ApiDown fires after 2 minutes (Prometheus -> Alerts)
```
(Argo selfHeal restores replicas; temporarily pause auto-sync in the UI to see the alert fire fully.)

**Alert routing:** Alertmanager has no receiver yet. Add Slack in the Helm values (`alertmanager.config.receivers` with a `slack_configs` entry whose webhook URL is read from a sealed secret) — exercise #6 in §15.

**Logs:** the API writes structured JSON to stdout. Read with `kubectl logs`; for a company-grade setup add Loki + Promtail (or your cloud's log service) as another Argo app.

---

## 10. Step 8 — Real cloud: Amazon EKS with AWS Secrets Manager (optional, costs money)

The complete, beginner-friendly, copy-paste walkthrough lives in **[`docs/EKS-DEPLOYMENT-GUIDE.md`](docs/EKS-DEPLOYMENT-GUIDE.md)**. It starts from "I have no AWS account" and ends with "everything deleted and verified". Summary of the flow:

| Part | What you do |
|---|---|
| A | Create the AWS account, MFA, a non-root admin user, a **budget alarm**, install and configure the AWS CLI |
| B | `init-project.sh … eks` (or `eks-nodomain`), public GitHub repo, wait for the first green CI run (it produces the `sha-…` image tag), make images public |
| C | `terraform/bootstrap`: state bucket, lock table, GitHub→AWS OIDC role |
| D | `terraform/envs/dev`: VPC, EKS 1.35, nodes (AL2023), EBS CSI driver, IAM role for External Secrets; gp3 StorageClass |
| E | `scripts/create-aws-secrets.sh staging|prod` (secrets in **AWS Secrets Manager**), `scripts/configure-eks.sh`, push |
| F | `scripts/bootstrap-argocd.sh --eks` → Argo CD installs Traefik (AWS load balancer), cert-manager, External Secrets, Prometheus/Grafana and both environments |
| G | DNS CNAMEs → load balancer (real certificates) or a hosts-file entry (self-signed) |
| H | Verify, promote to prod, break things on purpose |
| **J** | **`scripts/teardown-eks.sh` + a checklist of AWS CLI commands that prove nothing is left billing** |

How secrets work on EKS (no secret ever touches Git):
```
AWS Secrets Manager: bssons/prod/mongo {"username","password"}
        ▲ read-only IAM role (IRSA, only secrets named bssons/*)
External Secrets Operator ──► Kubernetes Secret "bssons-secrets" ──► Deployments (unchanged)
        ▲ rule lives in Git: k8s/overlays/<env>/external-secret.yaml
```

**Cost:** about US$0.40–0.50 per hour (≈ ₹1,000/day). **Always run the teardown the same day.**

## 11. Day-2 operations

| Task | How |
|---|---|
| **Deploy** | Merge PR → staging automatic → promote workflow → prod sync |
| **Roll back** | `git revert` + Sync (§8). Never `kubectl edit` in prod — selfHeal reverts it and it is unaudited |
| **Scale** | HPA automatic; change `minReplicas/maxReplicas` patch values in `k8s/overlays/<env>/kustomization.yaml` |
| **Change config** | Edit `k8s/base/configmap.yaml`, PR, merge (pods restart on the next deploy; or `kubectl rollout restart`) |
| **Rotate DB secret** | EKS: `aws secretsmanager put-secret-value …` then force-sync (see `docs/RUNBOOK.md`); kind: re-run `seal-secrets.sh` |
| **Backups** | Nightly CronJob; restore drill monthly: `scripts/backup-restore.md` |
| **Upgrade Kubernetes** | Terraform `kubernetes_version` one minor at a time (EKS standard support lasts ~14 months per version — check the EKS version calendar), staging cluster first |
| **Update dependencies** | Merge Dependabot PRs after CI is green |
| **Disaster recovery** | Cluster lost: re-run Terraform → `bootstrap-argocd.sh` → secrets: EKS = they are still in AWS Secrets Manager (nothing to restore); kind = restore the sealed-secrets key (below) → restore Mongo backup |

**Back up the Sealed Secrets private key** (without it, committed sealed secrets cannot be decrypted on a new cluster):
```bash
kubectl -n kube-system get secret -l sealedsecrets.bitnami.com/sealed-secrets-key=active -o yaml > sealed-secrets-key-backup.yaml
# store it in a password manager / vault. NEVER commit it (.gitignore blocks this filename, but still be careful).
```

---

## 12. Security model

| Layer | Controls |
|---|---|
| Code | CodeQL, ESLint, input validation, regex/NoSQL-injection tests, rate limiting, `helmet`, strict CORS |
| Dependencies | Lockfiles, `npm audit`, Dependabot, dependency-review |
| Secrets | gitleaks (CI + pre-commit), GitHub push protection, AWS Secrets Manager + External Secrets (EKS) or Sealed Secrets (kind), no secrets in images or Compose defaults |
| Images | Multi-stage minimal images, non-root, Trivy gate, SBOM, provenance, cosign signatures |
| Cluster | Pod Security `restricted`, read-only rootfs, dropped capabilities, no service-account tokens mounted, default-deny NetworkPolicy, resource limits |
| Transport | TLS everywhere at the edge (cert-manager), HSTS/CSP/frame headers in nginx and helmet |
| Delivery | GitOps pull model (cluster creds never in CI), protected branches, CODEOWNERS, approval-gated prod |
| Cloud | OIDC federation (no static keys), encrypted versioned state, private subnets for nodes |

Next hardening steps used in mature companies: verify cosign signatures at admission (Kyverno/Sigstore policy-controller), pin Actions by commit SHA, private cluster endpoint, WAF in front of ingress, least-privilege IAM for the CI role (the bootstrap uses `AdministratorAccess` only as a learning shortcut).

---

## 13. Troubleshooting

| Symptom | Likely cause → fix |
|---|---|
| `docker compose` fails: `set in .env` | You did not create `.env` → `cp .env.example .env` and fill values |
| Docker build: `npm ci` can only install with an existing package-lock.json | Run `make lock` and commit the lockfiles |
| CI `Image …` job fails Trivy | Real vulnerability: bump the base image / dependency (Dependabot PR), or if no fix exists keep `ignore-unfixed: true`; never disable the scan |
| `terraform fmt -check` fails in CI | Run `make tf-fmt` and commit |
| Bot cannot push to `main` (protected branch) | Configure `GITOPS_PAT` or bypass (§5.3 item 5) |
| Pods `ImagePullBackOff` (also: tag still `latest` — wait for the first CI run and `git pull`) | Package still private → make it public; or create a pull secret: `kubectl -n bssons-staging create secret docker-registry ghcr --docker-server=ghcr.io --docker-username=<user> --docker-password=<PAT with read:packages>` and add `imagePullSecrets: [{name: ghcr}]` to the ServiceAccounts (via a kustomize patch) |
| Pod stuck `CreateContainerConfigError` | `bssons-secrets` missing → run `seal-secrets.sh`, commit, sync; check `kubectl -n <ns> get sealedsecret` |
| Pod rejected: *violates PodSecurity "restricted"* | A manifest edit removed a securityContext field; compare with `k8s/base` |
| Backend `0/1 Ready` | DB down or wrong URI: `kubectl logs deploy/backend`, `kubectl get pods -l app=mongo`; if you re-sealed secrets after Mongo initialised, the old password is still in the PVC → delete the Mongo PVC in non-prod |
| `Certificate` never Ready | `kubectl describe certificate,challenge -A`; for kind/no-domain use the `kind`/`eks-nodomain` modes (self-signed); for real domains DNS must point to the load balancer first |
| `ServiceMonitor` "no matches for kind" on first sync | CRDs arrive with kube-prometheus-stack; Argo retries (`SkipDryRunOnMissingResource`) — wait or press Sync again |
| kind: ingress unreachable | Check `kubectl -n traefik get pods` (must run on the node labelled `ingress-ready`) and use `*.localtest.me:8443` (not 443). Argo UI port-forward uses 9443 |
| Argo shows app `OutOfSync` forever | `kubectl -n argocd describe application <name>` → conditions; usually a rendering error: `kubectl kustomize k8s/overlays/staging` locally |
| Everything slow on laptop | Increase Docker RAM; disable `alertmanager` / reduce Prometheus retention in the Helm values |

---

## 14. What is still missing for a *real* store

This repository makes the **platform** production-grade. The *application* is still a demo and needs product engineering before taking real money:

* Customer accounts, hashed passwords, admin roles and authorization
* Server-side cart/orders, price & stock validation, payment gateway integration (never touch card data), GST invoices
* Product images in object storage + CDN (replace the sample Unsplash links, which you do not own)
* MongoDB Atlas / DocumentDB or a 3-member replica set; point-in-time backup to object storage
* Centralised logs (Loki/ELK), tracing (OpenTelemetry), uptime checks, on-call rotation and alert routing
* Policy-as-code (Kyverno/OPA), image-signature admission, cost monitoring, load testing (k6) and SLOs

---

## 15. Practice exercises and interview talking points

**Exercises (in increasing difficulty)**
1. Break a unit test on purpose and watch the PR gate block the merge.
2. Add a `/api/products` field (e.g. `weightGrams`) → ship it through staging to prod using only Git.
3. Introduce a vulnerable dependency (`npm i lodash@4.17.15` in backend) → observe `npm audit`/dependency-review fail.
4. Commit a fake AWS key in a branch → watch gitleaks/push protection catch it.
5. Cause an outage in staging (wrong `MONGO_URI`) → diagnose using only the runbook and Grafana.
6. Add Slack alert routing in Alertmanager using a SealedSecret for the webhook.
7. Add Loki + Promtail as an Argo app and build a log panel next to the RED dashboard.
8. Add Kyverno and a policy that rejects unsigned images / images using `:latest`.
9. Add a k6 load test job in CI against staging and a Prometheus-based SLO (99% requests < 500 ms).
10. Convert MongoDB to a replica set (community operator) and test failover with `kubectl delete pod mongo-0`.

**How to explain this project in an interview (60 seconds)**
> "I took a MERN jewellery store and built the full delivery platform around it. Every PR runs lint, unit tests, secret and dependency scanning and CodeQL. On merge, GitHub Actions builds hardened non-root images, scans them with Trivy, generates an SBOM and signs them with cosign, pushes to GHCR, and commits the new immutable tag to Git. Argo CD, using a GitOps pull model, deploys to staging automatically and to production only after an approval-gated promotion PR and a manual sync. On Kubernetes I use Pod Security restricted, default-deny network policies, HPA, PDBs, readiness vs liveness probes, TLS via cert-manager and Sealed Secrets. Prometheus/Grafana give RED metrics with alerts linked to a runbook; MongoDB has nightly backups with a restore drill. The cluster itself is provisioned by Terraform with remote state and GitHub OIDC, so there are no long-lived cloud keys."

Be ready to discuss trade-offs: why GitOps over `kubectl apply` in CI, why separate liveness/readiness, why tags by SHA, what you would change for a real company (managed DB, separate prod cluster/account, SHA-pinned actions, admission policies).

---

## 16. Clean-up

```bash
make down && docker compose down -v        # Compose
make kind-down                              # local cluster
# AWS: scripts/teardown-eks.sh, then follow docs/EKS-DEPLOYMENT-GUIDE.md Part J (delete + verify) — always destroy the same day
```

---

## 17. What has and has not been verified

This project was assembled and checked in a sandbox **without access to the npm registry, a Docker daemon, a Kubernetes cluster or an AWS account**. Be aware:

| Checked in the sandbox | Not executable there (verify on your machine — each is a step above) |
|---|---|
| Every JS file passes `node --check` | `npm install` / `npm test` / `npm run lint` / `vite build` (dependencies could not be downloaded) |
| All YAML/JSON parse; kustomize file references resolve (`scripts/validate.py`); `docker compose config` accepts the Compose file | `kubectl kustomize`, kubeconform, real cluster behaviour |
| Shell scripts pass `bash -n`; `init-project.sh` (all modes) and `configure-eks.sh` tested on copies | Docker builds, Trivy results, GitHub Actions runs |
| Overlay patches reviewed against Kustomize semantics | Terraform `fmt/validate/plan/apply`, External Secrets and Traefik behaviour in a live cluster |

**Versions researched on 3 Nov 2026** (and what that changed): EKS 1.31 is already in paid extended support (ends 26 Nov 2026) → the project uses **1.35**; the Kubernetes project **retired ingress-nginx in March 2026** → replaced by **Traefik**; Argo CD **v3.4.13** (3.3–3.5 supported); cert-manager **1.21.x** (1.20–1.21 supported). Not verifiable from the sandbox: exact current versions of the Traefik, kube-prometheus-stack and Sealed Secrets charts (they use version ranges until you pin them, §7.3) and the External Secrets chart (pinned to `0.12.1` with the matching `v1beta1` API; newer charts may require `external-secrets.io/v1` — a one-line fix described in the EKS guide's troubleshooting table). Terraform uses the community EKS module 20.x, VPC module 5.x, IAM module 5.x and AWS provider 5.x; newer major versions exist and have different inputs, so keep those constraints until you deliberately migrate.

Expect to fix small issues on first run (typical: an ESLint rule, a Helm chart value, a Terraform fmt nit). That is normal DevOps work — use the Troubleshooting tables. The CI pipeline is designed so each problem surfaces as a failed, explained job before anything reaches a cluster.
