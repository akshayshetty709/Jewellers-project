// Process entrypoint: connects to MongoDB, starts HTTP, shuts down gracefully on SIGTERM (Kubernetes rollouts).
const mongoose = require('mongoose');
const config = require('./config');
const logger = require('./logger');
const app = require('./app');

async function main() {
  await mongoose.connect(config.mongoUri, { serverSelectionTimeoutMS: 10_000 });
  logger.info('MongoDB connected');

  const server = app.listen(config.port, () => logger.info({ port: config.port }, 'BSSONS API listening'));

  let shuttingDown = false;
  const shutdown = signal => {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info({ signal }, 'shutting down gracefully');
    const force = setTimeout(() => { logger.error('forced shutdown'); process.exit(1); }, config.shutdownTimeoutMs);
    force.unref();
    server.close(async () => {
      await mongoose.disconnect();
      logger.info('shutdown complete');
      process.exit(0);
    });
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch(err => { logger.fatal({ err }, 'startup failed'); process.exit(1); });
