// Structured JSON logs (one line per event) so Loki/ELK/CloudWatch can parse them.
const pino = require('pino');
const config = require('./config');

module.exports = pino({
  level: config.logLevel,
  base: { service: 'bssons-api', version: config.version },
  redact: ['req.headers.authorization', 'req.headers.cookie']
});
