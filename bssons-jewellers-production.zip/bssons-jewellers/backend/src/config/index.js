// Central, validated configuration (12-factor: everything comes from env vars).
require('dotenv').config();

const env = process.env.NODE_ENV || 'development';

const config = {
  env,
  isProd: env === 'production',
  port: Number(process.env.PORT) || 5000,
  mongoUri: process.env.MONGO_URI || 'mongodb://localhost:27017/bssons',
  logLevel: process.env.LOG_LEVEL || (env === 'test' ? 'silent' : 'info'),
  // Comma-separated list of allowed browser origins. Empty = same-origin only.
  corsOrigins: (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean),
  rateLimit: {
    windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS) || 60_000,
    max: Number(process.env.RATE_LIMIT_MAX) || 120
  },
  shutdownTimeoutMs: Number(process.env.SHUTDOWN_TIMEOUT_MS) || 10_000,
  version: process.env.APP_VERSION || 'dev'
};

if (config.isProd && !process.env.MONGO_URI) {
  throw new Error('MONGO_URI must be set in production');
}

module.exports = config;
