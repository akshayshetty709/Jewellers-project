const logger = require('../logger');

function notFound(_req, res) {
  res.status(404).json({ message: 'Not found' });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, _next) {
  logger.error({ err, path: req.path }, 'unhandled error');
  res.status(500).json({ message: 'Internal server error' }); // never leak internals
}

module.exports = { notFound, errorHandler };
