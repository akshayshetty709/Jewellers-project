// Express app factory kept separate from server.js so tests can import it without opening ports/DB.
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const pinoHttp = require('pino-http');
const config = require('./config');
const logger = require('./logger');
const { register, metricsMiddleware } = require('./metrics');
const { notFound, errorHandler } = require('./middleware/errors');
const healthRoutes = require('./routes/health');
const productRoutes = require('./routes/products');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1); // behind ingress / load balancer: needed for correct client IPs

app.use(helmet());
app.use(cors({ origin: config.corsOrigins.length ? config.corsOrigins : false }));
app.use(express.json({ limit: '100kb' }));
app.use(pinoHttp({
  logger,
  autoLogging: { ignore: req => req.url.startsWith('/api/health') || req.url === '/metrics' }
}));
app.use(metricsMiddleware);

// Health + metrics are mounted BEFORE the rate limiter so probes/scrapes are never throttled.
app.use('/api/health', healthRoutes);
app.get('/metrics', async (_req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

app.use('/api', rateLimit({ windowMs: config.rateLimit.windowMs, limit: config.rateLimit.max, standardHeaders: true, legacyHeaders: false }));
app.use('/api/products', productRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
