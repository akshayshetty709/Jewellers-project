const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();

// Liveness: "is the process up?" - must NOT depend on the database,
// otherwise a DB blip makes Kubernetes restart healthy pods.
const live = (_req, res) => res.json({ status: 'ok', service: 'bssons-api' });
router.get('/', live); // backwards compatible with /api/health
router.get('/live', live);

// Readiness: "can I serve traffic?" - fails (503) when MongoDB is not connected,
// so Kubernetes removes the pod from the Service until it recovers.
router.get('/ready', (_req, res) => {
  const connected = mongoose.connection.readyState === 1;
  res.status(connected ? 200 : 503).json({ status: connected ? 'ready' : 'not-ready', db: connected });
});

module.exports = router;
