const express = require('express');
const mongoose = require('mongoose');
const Product = require('../models/Product');
const router = express.Router();

const escapeRegex = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // prevents regex injection / ReDoS
const CATEGORIES = ['Gold', 'Silver', 'Platinum', 'Diamond', 'Rings', 'Bracelets', 'Gents Chains', 'Ladies Chains'];

router.get('/', async (req, res, next) => {
  try {
    // typeof checks block NoSQL-injection payloads such as ?category[$ne]=x
    const category = typeof req.query.category === 'string' ? req.query.category : undefined;
    const search = typeof req.query.search === 'string' ? req.query.search.slice(0, 60) : undefined;
    const filter = {};
    if (category && category !== 'All') {
      if (!CATEGORIES.includes(category)) return res.status(400).json({ message: 'Invalid category' });
      filter.category = category;
    }
    if (search) filter.name = { $regex: escapeRegex(search), $options: 'i' };
    if (req.query.featured === 'true') filter.featured = true;
    const products = await Product.find(filter).sort({ featured: -1, createdAt: -1 }).limit(100).lean();
    res.json(products);
  } catch (error) { next(error); }
});

router.get('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid product id' });
    const product = await Product.findById(req.params.id).lean();
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json(product);
  } catch (error) { next(error); }
});

module.exports = router;
