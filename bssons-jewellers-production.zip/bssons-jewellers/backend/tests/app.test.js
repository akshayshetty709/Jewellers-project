process.env.NODE_ENV = 'test';
const request = require('supertest');

// Mock the Product model so unit tests need no database.
jest.mock('../src/models/Product', () => ({ find: jest.fn(), findById: jest.fn() }));
const Product = require('../src/models/Product');
const app = require('../src/app');

const chain = result => ({ sort: () => ({ limit: () => ({ lean: () => Promise.resolve(result) }) }) });

describe('health', () => {
  test('GET /api/health/live returns ok', async () => {
    const res = await request(app).get('/api/health/live');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });
  test('GET /api/health/ready returns 503 when DB is down', async () => {
    const res = await request(app).get('/api/health/ready');
    expect(res.status).toBe(503);
  });
});

describe('products', () => {
  beforeEach(() => jest.clearAllMocks());

  test('lists products', async () => {
    Product.find.mockReturnValue(chain([{ name: 'Ring' }]));
    const res = await request(app).get('/api/products');
    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(1);
  });

  test('escapes regex characters in search (no regex injection)', async () => {
    Product.find.mockReturnValue(chain([]));
    await request(app).get('/api/products').query({ search: '.*(a+)+$' });
    const filter = Product.find.mock.calls[0][0];
    expect(filter.name.$regex).toBe('\\.\\*\\(a\\+\\)\\+\\$');
  });

  test('rejects NoSQL operator injection via category[$ne]', async () => {
    Product.find.mockReturnValue(chain([]));
    const res = await request(app).get('/api/products?category[$ne]=x');
    expect(res.status).toBe(200);
    expect(Product.find.mock.calls[0][0]).toEqual({}); // non-string category is ignored
  });

  test('rejects unknown category', async () => {
    const res = await request(app).get('/api/products?category=Hacked');
    expect(res.status).toBe(400);
  });

  test('rejects malformed id', async () => {
    const res = await request(app).get('/api/products/not-an-id');
    expect(res.status).toBe(400);
  });

  test('404 for unknown product', async () => {
    Product.findById.mockReturnValue({ lean: () => Promise.resolve(null) });
    const res = await request(app).get('/api/products/507f1f77bcf86cd799439011');
    expect(res.status).toBe(404);
  });
});

describe('platform', () => {
  test('exposes Prometheus metrics', async () => {
    const res = await request(app).get('/metrics');
    expect(res.status).toBe(200);
    expect(res.text).toContain('http_requests_total');
  });
  test('sets security headers and hides x-powered-by', async () => {
    const res = await request(app).get('/api/health/live');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });
  test('unknown route returns JSON 404', async () => {
    const res = await request(app).get('/nope');
    expect(res.status).toBe(404);
  });
});
