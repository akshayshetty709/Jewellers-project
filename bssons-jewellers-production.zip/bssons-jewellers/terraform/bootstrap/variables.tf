variable "region" {
  type    = string
  default = "ap-south-1"
}

variable "github_repo" {
  type        = string
  description = "owner/repo allowed to assume the CI role, e.g. akshay/bssons-jewellers"
}

variable "force_destroy" {
  type        = bool
  default     = false
  description = "Allow terraform destroy to delete the state bucket even though it contains state files"
}
