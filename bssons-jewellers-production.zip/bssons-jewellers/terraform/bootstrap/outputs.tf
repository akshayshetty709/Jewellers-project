output "state_bucket" { value = aws_s3_bucket.state.id }
output "lock_table" { value = aws_dynamodb_table.lock.name }
output "github_actions_role_arn" {
  value       = aws_iam_role.github_actions.arn
  description = "Store this as the GitHub secret AWS_ROLE_ARN"
}
