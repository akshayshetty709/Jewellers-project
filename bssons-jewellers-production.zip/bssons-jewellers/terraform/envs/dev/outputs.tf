output "cluster_name" { value = module.eks.cluster_name }
output "region" { value = var.region }
output "kubeconfig_command" {
  value = "aws eks update-kubeconfig --region ${var.region} --name ${module.eks.cluster_name}"
}
output "external_secrets_role_arn" {
  value       = module.external_secrets_irsa.iam_role_arn
  description = "IAM role the External Secrets Operator assumes (written into argocd/apps-eks/external-secrets.yaml by scripts/configure-eks.sh)"
}
output "account_id" { value = data.aws_caller_identity.current.account_id }
