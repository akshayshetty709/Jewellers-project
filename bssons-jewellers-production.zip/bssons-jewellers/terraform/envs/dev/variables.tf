variable "region" {
  type    = string
  default = "ap-south-1"
}

variable "environment" {
  type    = string
  default = "dev"
}

variable "cluster_name" {
  type    = string
  default = "bssons-dev"
}

variable "kubernetes_version" {
  type    = string
  default = "1.35" # EKS standard support until 27 Mar 2027 (check the EKS version calendar before applying)
}

variable "vpc_cidr" {
  type    = string
  default = "10.20.0.0/16"
}

variable "node_instance_types" {
  type    = list(string)
  default = ["t3.large"] # Prometheus + Argo CD + app need ~8 GB across nodes
}

variable "node_min_size" {
  # t3.large allows ~35 pods per node (ENI limit) and has 8 GB RAM; Argo CD + monitoring + both environments need ~55 pods
  type    = number
  default = 2
}

variable "node_max_size" {
  type    = number
  default = 4
}
