terraform {
  required_version = ">= 1.6"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.95" }
  }
  backend "s3" {} # configured via -backend-config=backend.hcl
}

provider "aws" {
  region = var.region
  default_tags { tags = { Project = "bssons-jewellers", Environment = var.environment, ManagedBy = "terraform" } }
}
